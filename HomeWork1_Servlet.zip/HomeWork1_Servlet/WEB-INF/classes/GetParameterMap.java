import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GetParameterMap extends HttpServlet  
{
    protected void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
    {
        PrintWriter out=response.getWriter();
		String title = "Reading Parameters using GetParameterMap";
        response.setContentType("text/html");
		out.println("<H1 ALIGN=CENTER>" + title + "</H1>\n");

        Map map=request.getParameterMap();
        Set s = map.entrySet();
        Iterator iterator = s.iterator();

            while(iterator.hasNext()){

                Map.Entry<String,String[]> entry = (Map.Entry<String,String[]>)iterator.next();

                String key             = entry.getKey();
                String[] value         = entry.getValue();

                out.println(key);

                    if(value.length>1){    
                        for (int i = 0; i < value.length; i++) {
                            out.println("<li>" + value[i].toString() + "</li><br>");
                        }
                    }else
                            out.println(value[0].toString()+"<br>");
            }

        out.close();    
    }
}