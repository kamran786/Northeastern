import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
 
public class ServletUserForm extends HttpServlet {
	
	    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    }
 
 @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
         
        // read form fields
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
        String email = request.getParameter("email");
        String password = request.getParameter("password");
		String filepath = request.getParameter("file");
		String gender = request.getParameter("gender");
		String country = request.getParameter("country");
		String hobbies[] = request.getParameterValues("sports");
		String address = request.getParameter("address");

		
	String title = "User Details";
	out.println("<html>");
    out.println("<head>");
    out.println("<title>" + title +"</title>");
    out.println("</head>");
    out.println("<body>");
		
      out.println("<p>Email: " + email +"</p>");
		out.println("<p>Password: " + password +"</p>");
		out.println("<p>Image Path: " + filepath +"</p>");
		out.println("<p>Gender: " + gender + "</p");
		out.println("<p>Country: " + country + "</p>");
		if (hobbies != null) {
        out.println("<p>Hobbies are:");
        for (String hobby : hobbies) {
        out.println("\t" + hobby + "</p>");
		
    }
}
		out.println("Address: " + address);
		out.println("</TABLE>\n</BODY></HTML>");
         
    }
 
}