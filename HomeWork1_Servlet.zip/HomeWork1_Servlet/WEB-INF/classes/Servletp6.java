import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Servletp6 extends HttpServlet {
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String cnt = request.getParameter("cnt");
		if (cnt == null)
		{
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Servletp6</title>");			
			out.println("<script type='text/javascript'>");
			out.println("function pageGenerate() {");
			out.println("var a = parseInt(document.getElementById('cnt').value);");
			out.println("var url = 'http://localhost:8080/HomeWork1/Servletp6?cnt=' +a ;");
			out.println("window.location= url;");		
			out.println("}");
			out.println("</script>");			
			out.println("</head>");
			out.println("<body>");
			out.println("How many Children do you have?");
			out.println("<input type='text' name='cnt' id='cnt' /><br />");			
			out.println("<input type='button' value ='Submit Query' onclick='pageGenerate()'/>");
			out.println("<div id='ch'></div>");
			out.println("</body>");
			out.println("</html>");
		}
		else
		{
			int c = Integer.parseInt(cnt);
			HttpSession session = request.getSession();
			session.setAttribute("cnt",c);
			out.println("<html>");
			out.println("<head>");
			out.println("</head>");
			out.println("<body>");
			out.println("<form action = 'Servletp6' method = 'post'>");
			for(int i=0;i<c;i++)
			{
				String name = "c"+(i+1);
				out.println("Please Enter the name of Child " +(i+1) + "<br /><br />");
				out.println("<input type='text' name="+name+" id='cnt' /><br /><br />");
				
			}
			out.println("<input type =  'submit' value = 'Submit' name = 'Submit'/><br /></p>");
			out.println("<div id='ch'></div>");
			out.println("</form>");
			out.println("</body>");
			out.println("</html>");
			
		}
			
	}
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();	
		int c = (Integer) session.getAttribute("cnt");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Servletp6</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("Your Children name(s) are : <br />");
		
		for(int i=0;i<c;i++)
			{
				String name = "c"+(i+1);
				out.println((String)request.getParameter(name));
				out.println("<br />");
				
			}
		out.println("</body>");
		out.println("</html>");
		
    }
}