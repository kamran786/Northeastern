/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface.NurseRole;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Organization.LabAssistOrganization;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import Business.WorkQueue.Patient;
import java.awt.CardLayout;
import java.awt.Component;
import javax.swing.JPanel;
import userinterface.LabAssistantRole.LabAssistantWorkAreaJPanel;

/**
 *
 * @author kahma
 */
public class ProcessWorkRequestNurseJPanel extends javax.swing.JPanel {

    /**
     * Creates new form ProcessWorkRequestNurseJPanel
     */
    private JPanel userProcessContainer;
    private UserAccount userAccount;
    private LabAssistOrganization labOrganization;
    private Patient patient;
    private Enterprise enterprise;
    
    /**
     * Creates new form LabAssistantWorkAreaJPanel
     */
    public ProcessWorkRequestNurseJPanel(JPanel userProcessContainer, Patient patient) {
        initComponents();
        
        this.userProcessContainer = userProcessContainer;
        this.patient = patient;
        pName.setText(patient.getName());
        pAge.setText(String.valueOf(patient.getAge()));
        pGender.setText(patient.getGender());
//        requestedBy.setText(TOOL_TIP_TEXT_KEY);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        pName = new javax.swing.JTextField();
        pAge = new javax.swing.JTextField();
        pGender = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        bpText = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        diabetesText = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        feverText = new javax.swing.JTextArea();
        requestedBy = new javax.swing.JTextField();
        submitBtn = new javax.swing.JButton();
        backBtn = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Calibri", 0, 20)); // NOI18N
        jLabel1.setText("Patient Name : ");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 190, -1, -1));

        jLabel2.setFont(new java.awt.Font("Calibri", 0, 20)); // NOI18N
        jLabel2.setText("Age : ");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 240, -1, -1));

        jLabel3.setFont(new java.awt.Font("Calibri", 0, 20)); // NOI18N
        jLabel3.setText("Gender :");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 284, -1, -1));

        jLabel4.setFont(new java.awt.Font("Calibri", 0, 20)); // NOI18N
        jLabel4.setText("Requested By :");
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 334, -1, -1));

        jLabel5.setFont(new java.awt.Font("Calibri", 0, 20)); // NOI18N
        jLabel5.setText("Test Result (Fever) :");
        add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 403, -1, -1));

        jLabel6.setFont(new java.awt.Font("Calibri", 0, 20)); // NOI18N
        jLabel6.setText("Test Result (Diabetes) :");
        add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 531, -1, -1));

        jLabel7.setFont(new java.awt.Font("Calibri", 0, 20)); // NOI18N
        jLabel7.setText("Test Result (Blood Pressure) :");
        add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 663, -1, -1));
        add(pName, new org.netbeans.lib.awtextra.AbsoluteConstraints(347, 192, 247, -1));
        add(pAge, new org.netbeans.lib.awtextra.AbsoluteConstraints(347, 244, 113, -1));

        pGender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pGenderActionPerformed(evt);
            }
        });
        add(pGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(347, 286, 113, -1));

        bpText.setColumns(20);
        bpText.setRows(5);
        jScrollPane1.setViewportView(bpText);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(347, 663, 247, -1));

        diabetesText.setColumns(20);
        diabetesText.setRows(5);
        jScrollPane2.setViewportView(diabetesText);

        add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(347, 531, 247, -1));

        feverText.setColumns(20);
        feverText.setRows(5);
        jScrollPane3.setViewportView(feverText);

        add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(347, 403, 247, -1));

        requestedBy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                requestedByActionPerformed(evt);
            }
        });
        add(requestedBy, new org.netbeans.lib.awtextra.AbsoluteConstraints(347, 336, 247, -1));

        submitBtn.setBackground(new java.awt.Color(102, 204, 255));
        submitBtn.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        submitBtn.setText("Submit");
        submitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBtnActionPerformed(evt);
            }
        });
        add(submitBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(555, 799, 166, -1));

        backBtn.setBackground(new java.awt.Color(255, 255, 255));
        backBtn.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        backBtn.setText("Back");
        backBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtnActionPerformed(evt);
            }
        });
        add(backBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 799, 147, -1));

        jPanel1.setBackground(new java.awt.Color(102, 204, 255));

        jLabel8.setFont(new java.awt.Font("Calibri", 1, 36)); // NOI18N
        jLabel8.setText("Patient Test Details");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(295, 295, 295)
                .addComponent(jLabel8)
                .addContainerGap(308, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(jLabel8)
                .addContainerGap(62, Short.MAX_VALUE))
        );

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 891, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void pGenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pGenderActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pGenderActionPerformed

    private void requestedByActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_requestedByActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_requestedByActionPerformed

    private void submitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBtnActionPerformed
        // TODO add your handling code here:
        
        patient.getRequestRoutineCheckup().setBloodPressureTest(bpText.getText());
        patient.getRequestRoutineCheckup().setDiabetesTest(diabetesText.getText());
        patient.getRequestRoutineCheckup().setFeverTest(feverText.getText());
        patient.setStatus("Completed");
    }//GEN-LAST:event_submitBtnActionPerformed

    private void backBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBtnActionPerformed
        // TODO add your handling code here:
        userProcessContainer.remove(this);
        Component[] componentArray = userProcessContainer.getComponents();
        Component component = componentArray[componentArray.length - 1];
        NurseWorkAreaJPanel dwjp = (NurseWorkAreaJPanel) component;
        dwjp.populateTable();
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_backBtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backBtn;
    private javax.swing.JTextArea bpText;
    private javax.swing.JTextArea diabetesText;
    private javax.swing.JTextArea feverText;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField pAge;
    private javax.swing.JTextField pGender;
    private javax.swing.JTextField pName;
    private javax.swing.JTextField requestedBy;
    private javax.swing.JButton submitBtn;
    // End of variables declaration//GEN-END:variables
}
