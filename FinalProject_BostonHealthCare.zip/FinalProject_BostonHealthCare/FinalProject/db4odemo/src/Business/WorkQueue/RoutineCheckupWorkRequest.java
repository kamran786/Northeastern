/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

/**
 *
 * @author kahma
 */
public class RoutineCheckupWorkRequest {
    
    private String feverTest;
    private String diabetesTest;
    private String bloodPressureTest;

    public String getFeverTest() {
        return feverTest;
    }

    public void setFeverTest(String feverTest) {
        this.feverTest = feverTest;
    }

    public String getDiabetesTest() {
        return diabetesTest;
    }

    public void setDiabetesTest(String diabetesTest) {
        this.diabetesTest = diabetesTest;
    }

    public String getBloodPressureTest() {
        return bloodPressureTest;
    }

    public void setBloodPressureTest(String bloodPressureTest) {
        this.bloodPressureTest = bloodPressureTest;
    }

}
