/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.UserAccount.UserAccount;
import java.util.Date;

/**
 *
 * @author raunak
 */
    public class Patient {

    private String name;
    private String diag;
    private int age;
    private String gender;
    private String tests;
    private UserAccount sender;
    private UserAccount receiver;
    private String status;
    private int patientId;
    private long contactNum;
    private String address;
    private static int count = 1;
    private String email;
    private String checkupDate;
    private LabTestWorkRequest labTestWorkRequest;
    private RoutineCheckupWorkRequest requestRoutineCheckup;
    private DoctorPharmacyWorkRequest doctorPharmacyWorkRequest;

    public String getCheckupDate() {
        return checkupDate;
    }

    public void setCheckupDate(String checkupDate) {
        this.checkupDate = checkupDate;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getContactNum() {
        return contactNum;
    }

    public void setContactNum(long contactNum) {
        this.contactNum = contactNum;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public LabTestWorkRequest getLabTestWorkRequest() {
        return labTestWorkRequest;
    }

    public void setLabTestWorkRequest(LabTestWorkRequest labTestWorkRequest) {
        this.labTestWorkRequest = labTestWorkRequest;
    }

    public RoutineCheckupWorkRequest getRequestRoutineCheckup() {
        return requestRoutineCheckup;
    }

    public void setRequestRoutineCheckup(RoutineCheckupWorkRequest requestRoutineCheckup) {
        this.requestRoutineCheckup = requestRoutineCheckup;
    }


    public static void setCount(int count) {
        Patient.count = count;
    }


    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }
    
    public Patient(){
        patientId = count;
//        patient = new Patient();
        labTestWorkRequest = new LabTestWorkRequest();
        requestRoutineCheckup = new RoutineCheckupWorkRequest();
        count++;
    }

    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDiag() {
        return diag;
    }

    public void setDiag(String diag) {
        this.diag = diag;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getTests() {
        return tests;
    }

    public void setTests(String tests) {
        this.tests = tests;
    }
    
    public UserAccount getSender() {
        return sender;
    }

    public void setSender(UserAccount sender) {
        this.sender = sender;
    }

    public UserAccount getReceiver() {
        return receiver;
    }

    public void setReceiver(UserAccount receiver) {
        this.receiver = receiver;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public DoctorPharmacyWorkRequest getDoctorPharmacyWorkRequest() {
        return doctorPharmacyWorkRequest;
    }

    public void setDoctorPharmacyWorkRequest(DoctorPharmacyWorkRequest doctorPharmacyWorkRequest) {
        this.doctorPharmacyWorkRequest = doctorPharmacyWorkRequest;
    }

    
    @Override
    public String toString() {
        return name;
    }
    
}
