/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Organization.Organization.Type;
import java.util.ArrayList;

/**
 *
 * @author monag
 */
public class OrganizationDirectory {
    
    private ArrayList<Organization> organizationList;

    public OrganizationDirectory() {
        organizationList = new ArrayList();
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationList;
    }
    
    public Organization createOrganization(Type type){
        Organization organization = null;
        if (type.getValue().equals(Type.Doctor.getValue())){
            organization = new DoctorOrganization();
            organizationList.add(organization);
        }
        if (type.getValue().equals(Type.Nurse.getValue())){
            organization = new NurseOrganization();
            organizationList.add(organization);
        }
//        if (type.getValue().equals(Type.Pharmacy.getValue())){
//            organization = new PharmacistOrganization();
//            organizationList.add(organization);
//        }
        if (type.getValue().equals(Type.LabAssist.getValue())){
            organization = new LabAssistOrganization();
            organizationList.add(organization);
        }
        if (type.getValue().equals(Type.HReceptionist.getValue())){
            organization = new HReceptionistOrganization();
            organizationList.add(organization);
        }
        if (type.getValue().equals(Type.PathologyReceptionist.getValue())){
            organization = new PathologyReceptionistOrganization();
            organizationList.add(organization);
        }
        if (type.getValue().equals(Type.PReceptionist.getValue())){
            organization = new PharmacistOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.LabReceptionist.getValue())){
            organization = new PathologyReceptionistOrganization();
            organizationList.add(organization);
        }
        return organization;
    }
}