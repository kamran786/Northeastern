/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

//import Business.LabOrganizations.LabOrganizations;
import Business.Role.PathologyReceptionistRole;
import Business.Role.Role;
//import Business.PathologyRole.Role;
import java.util.ArrayList;

/**
 *
 * @author raunak
 */
public class LabAssistOrganization extends Organization{

    public LabAssistOrganization() {
        super(Organization.Type.LabAssist.getValue());
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList();
        roles.add(new PathologyReceptionistRole());
//        roles.add(new LabAssistRole());
        return roles;
    }
     
   
    
    
}
