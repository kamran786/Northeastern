/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Role.HReceptionistRole;
import Business.Role.PathologyReceptionistRole;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author monag
 */
public class PathologyReceptionistOrganization extends Organization {
    
    public PathologyReceptionistOrganization() {
        super(Organization.Type.PathologyReceptionist.getValue());
    }
    
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList();
        roles.add(new PathologyReceptionistRole());
        return roles;
    }
}

