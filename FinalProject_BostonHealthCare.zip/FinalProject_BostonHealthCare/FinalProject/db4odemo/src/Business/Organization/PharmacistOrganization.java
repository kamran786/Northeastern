/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Organization.Organization;
import Business.Role.AdminRole;
import Business.Role.PharmacistReceptionistRole;
import Business.Role.Role;
import java.util.ArrayList;
/**
 *
 * @author kahma
 */
public class PharmacistOrganization extends Organization{
    
    public PharmacistOrganization() {
        super(Organization.Type.PReceptionist.getValue());
    }
    
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList();
        roles.add(new PharmacistReceptionistRole());
        return roles;
    }
}
