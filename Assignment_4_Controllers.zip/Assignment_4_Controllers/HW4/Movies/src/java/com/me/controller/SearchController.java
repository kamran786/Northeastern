/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.me.controller;

import com.me.dao.MoviesDAO;
import com.me.pojo.Movies;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author kahma
 */
public class SearchController extends AbstractController  {

    @Override
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {

            String searchType = request.getParameter("searchType");
            String searchQuery = request.getParameter("query");
            ModelAndView mav = null;
             
            MoviesDAO mdao = (MoviesDAO) this.getApplicationContext().getBean("MoviesDAO");
          
            if (searchType.equals("title")) {
                ArrayList<Movies> moviesList = mdao.getMovies(searchQuery);
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("moviesList", moviesList);

                mav = new ModelAndView("moviesView", "map", map);

            } else if (searchType.equals("actor")) {
                ArrayList<Movies> moviesList = mdao.getMoviesA(searchQuery);
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("moviesList", moviesList);

                mav = new ModelAndView("moviesView", "map", map);

            }
            else if (searchType.equals("actress")) {
                ArrayList<Movies> moviesList = mdao.getMoviesAC(searchQuery);
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("moviesList", moviesList);

                mav = new ModelAndView("moviesView", "map", map);

            }
            
            return mav;
        
        
    }                               
   
}
