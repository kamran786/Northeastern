/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.me.dao;

import com.me.pojo.Movies;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author kahma
 */
public class MoviesDAO {
    
    public boolean checkMovies(Movies movies){
        
        Statement stmt = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
           System.out.println("ClassNotFoundException" + e.getMessage());
        }
        
        Connection connection = null;
        try {
            //Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviesdb", "root", "Kemp@123");
        } 
        catch (SQLException ex) {
            System.out.println("SQLException" + ex.getMessage());
        }
        
        if (connection
                != null) {
        System.out.println(movies.getActor());
        String query = "Insert into movies(title, actor,actress,genre,`year`) values('" + movies.getTitle()+"', '" + movies.getActor()+"', '" + movies.getActress()+"','" +movies.getGenre()+"', '" + movies.getYear()+"')";
          System.out.println(query);
        try {
             stmt = connection.createStatement();
            int result = stmt.executeUpdate(query);

           
           if (result == 0) {
            throw new SQLException("No rows affected.");
        }

           else{
                return true;
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        } 
        
//        finally {
//            try {
//                if (stmt != null) {
//                    stmt.close();
//                }
//                if (connection != null) {
//                    connection.close();
//                }
//            } catch (SQLException ex) {
//                System.out.println("SQLException" + ex.getMessage());
//            }
//        }
        }
        return false;
        
    }
    
    public ArrayList<Movies> getMovies(String title) {
        java.sql.Connection connection = null;
        Statement stmt = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviesdb", "root", "Kemp@123");
            stmt = connection.createStatement();
        } catch (ClassNotFoundException ex) {
            System.out.println("ClassNotFoundException" + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("SQLException" + ex.getMessage());
        }
        System.out.println(title);
        String query = "SELECT * FROM movies where title like'" + title + "'";
        ArrayList<Movies> moviesList = new ArrayList<Movies>();
        try {
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                Movies movies = new Movies();
                movies.setTitle(rs.getString("title"));
                movies.setActor(rs.getString("actor"));
                movies.setActress(rs.getString("actress"));
                movies.setGenre(rs.getString("genre"));
                movies.setYear(rs.getInt("year"));
                moviesList.add(movies);
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                System.out.println("SQLException" + ex.getMessage());
            }
        }

        return moviesList;
    }
public ArrayList<Movies> getMoviesA(String actor) {
          java.sql.Connection connection = null;
        Statement stmt = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviesdb", "root", "Kemp@123");
            stmt = connection.createStatement();
        } catch (ClassNotFoundException ex) {
            System.out.println("ClassNotFoundException" + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("SQLException" + ex.getMessage());
        }
        System.out.println(actor);
        String query = "SELECT * FROM movies where actor like'" + actor + "'";
        ArrayList<Movies> moviesList = new ArrayList<Movies>();
        try {
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                Movies movies = new Movies();
                movies.setTitle(rs.getString("title"));
                movies.setActor(rs.getString("actor"));
                movies.setActress(rs.getString("actress"));
                movies.setGenre(rs.getString("genre"));
                movies.setYear(rs.getInt("year"));
                moviesList.add(movies);
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                System.out.println("SQLException" + ex.getMessage());
            }
        }

        return moviesList;
    }
 public ArrayList<Movies> getMoviesAC(String actress) {
          java.sql.Connection connection = null;
        Statement stmt = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviesdb", "root", "Kemp@123");
            stmt = connection.createStatement();
        } catch (ClassNotFoundException ex) {
            System.out.println("ClassNotFoundException" + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("SQLException" + ex.getMessage());
        }
        System.out.println(actress);
        String query = "SELECT * FROM movies where actress like'" + actress + "'";
        ArrayList<Movies> moviesList = new ArrayList<Movies>();
        try {
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                Movies movies = new Movies();
                movies.setTitle(rs.getString("title"));
                movies.setActor(rs.getString("actor"));
                movies.setActress(rs.getString("actress"));
                movies.setGenre(rs.getString("genre"));
                movies.setYear(rs.getInt("year"));
                moviesList.add(movies);
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                System.out.println("SQLException" + ex.getMessage());
            }
        }

        return moviesList;
    }
}
