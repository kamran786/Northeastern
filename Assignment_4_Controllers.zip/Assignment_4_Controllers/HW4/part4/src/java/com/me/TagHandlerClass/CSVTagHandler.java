/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.me.TagHandlerClass;

import com.neu.edu.pojo.SalesOrder;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;
/**
 *
 * @author Romell
 */
public class CSVTagHandler extends SimpleTagSupport {

    private String CSVFileName;
    int i = 1;

    /**
     * Called by the container to invoke this tag. The implementation of this
     * method is provided by the tag library developer, and handles all tag
     * processing, body iteration, etc.
     */
    @Override
    public void doTag() throws JspException, IOException {
        JspWriter out = getJspContext().getOut();
//        HttpServletRequest request = (HttpServletRequest)getJspContext().get.getRequest();
//        HttpSession session = request.getSession();
      
        
       
        ArrayList<SalesOrder>orderList=new ArrayList<SalesOrder>();
        
       
            //if (CSVFileNAme.equals("SalesOrder1.csv")) {
                try {
                    Class.forName("org.relique.jdbc.csv.CsvDriver");
                } catch (ClassNotFoundException ex) {
                    System.out.println(ex);
                }
            

            // Create a connection. The first command line parameter is
            // the directory containing the .csv files.
            // A single connection is thread-safe for use by several threads.  c:/mydir/csvfiles
            Connection conn;//C:\
            try {//localhost:3306/booksdb.sql.SQLException) java.sql.SQLException: Directory not found: C:\SalesOrder\
                conn = DriverManager.getConnection("jdbc:relique:csv:C:");
                Statement stmt = conn.createStatement();

                // Select the ID and NAME columns from sample.csv
                ResultSet results = stmt.executeQuery("SELECT SalesOrderID,RevisionNumber,OrderDate,DueDate,ShipDate,Status,OnlineOrderFlag,SalesOrderNumber,PurchaseOrderNumber,AccountNumber,CustomerID,SalesPersonID,TerritoryID,BillToAddressID,ShipToAddressID,ShipMethodID,CreditCardID,CreditCardApprovalCode,CurrencyRateID,SubTotal,TaxAmt,Freight,TotalDue,Comment,ModifiedDate FROM " + CSVFileName);

                while (results.next()) {
                    SalesOrder sOrder = new SalesOrder();
                    sOrder.setSalesOrder(results.getString("SalesOrderID"));
                    sOrder.setRevisionNumber(results.getString("RevisionNumber"));
                    sOrder.setOrderDate(results.getString("OrderDate"));
                    sOrder.setDueDate(results.getString("DueDate"));
                    sOrder.setShipDate(results.getString("ShipDate"));
                    sOrder.setStatus(Integer.parseInt(results.getString("Status")));
                    sOrder.setOnlineOrderFlag(Integer.parseInt(results.getString("OnlineOrderFlag")));
                    sOrder.setSalesOrderNumber(results.getString("SalesOrderNumber"));
                    sOrder.setPurchaseOrderNumber(results.getString("PurchaseOrderNumber"));
                    sOrder.setAccountNumber(results.getString("AccountNumber"));
                    sOrder.setCustomerId(Integer.parseInt(results.getString("CustomerID")));
                    sOrder.setSalesPersonId(results.getString("SalesPersonID"));
                    sOrder.setTerritoryId(results.getString("TerritoryID"));
                    sOrder.setBillToaddressId(results.getString("BillToAddressID"));
                    sOrder.setShipToaddressId(results.getString("ShipToAddressID"));
                    sOrder.setShipMethodId(results.getString("ShipMethodID"));
                    sOrder.setCreditCardId(results.getString("CreditCardID"));
                    sOrder.setCreditCardApprovalCode(results.getString("CreditCardApprovalCode"));
                    sOrder.setCurrencyRateID(results.getString("CurrencyRateID"));
                    sOrder.setSubTotal(Float.parseFloat(results.getString("SubTotal")));
                    sOrder.setTaxAmnt(Float.parseFloat(results.getString("TaxAmt")));
                    sOrder.setFreight(Float.parseFloat(results.getString("Freight")));
                    sOrder.setTotalDue(Float.parseFloat(results.getString("TotalDue")));
                    sOrder.setComment(results.getString("Comment"));
                    sOrder.setModifiedDate(results.getString("ModifiedDate"));
                    orderList.add(sOrder);
                }

                // Dump out the results to a CSV file with the same format
                // using CsvJdbc helper function
                boolean append = true;
                //CsvDriver.writeToCsv(results, System.out, append);

                // Clean up
                conn.close();

            } catch (SQLException ex) {
               System.out.println(ex);
            }

            // Create a Statement object to execute the query with.
            // A Statement is not thread-safe.
            out.print("  <form method=post action=index.htm>");
            out.print("<input type='submit'  value='Submit'/>");
            out.print("<input type='hidden'  name='database' value='db'/>");
            out.print("       <table>"
                    + "<tr><th> salesOrderID</th>"
                    + "    <th> revisionNumber</th>"
                    + "    <th> orderDate</th>"
                    + "   <th> dueDate</th>"
                    + "   <th> shipDate</th>"
                    + "   <th> status</th>"
                    + "   <th> onlineOrderFlag</th>"
                    + "   <th> salesOrderNumber</th>"
                    + "   <th> purchaseOrderNumber</th>"
                    + "  <th> accountNumber</th>"
                    + "  <th> customerID</th>"
                    + "  <th> salesPersonID</th>"
                    + "  <th> territoryID</th>"
                    + "  <th> billToAddressID</th>"
                    + "  <th> shipToAddressID</th>"
                    + "  <th> shipMethodID</th>"
                    + "  <th> creditCardID</th>"
                    + " <th> currencyRateID</th>"
                    + " <th> subTotal</th>"
                    + " <th> taxAmt</th>"
                    + "  <th> freight</th>"
                    + "  <th> totalDue</th>"
                    + "  <th> comment</th>"
                    + "  <th> modifiedDate</th>"
                    + "  <th> creditCardApprovalCode</th>"
                    + " </tr>");

            for (SalesOrder order : orderList) {
                    
                        out.print("<tr><td><input type=text name=salesOrderID value="+order.getSalesOrder()+"></input></td>"
                   +"   <td><input type=text name=revisionNumber value="+order.getRevisionNumber()+"></input></td>"
                   +"  <td><input type=text name=orderDate value="+order.getOrderDate()+"></input></td>"
                   + " <td><input type=text name=dueDate value="+order.getDueDate()+"></input></td>"
                   +"  <td><input type=text name=shipDate value="+order.getShipDate()+"></input></td>"
                   +"  <td><input type=text name=status value="+order.getStatus()+"></input></td>"
                   
                   +"  <td><input type=text name=onlineOrderFlag value="+order.getOnlineOrderFlag()+"></input></td>"
                   +" <td><input type=text name=salesOrderNumber value="+order.getSalesOrderNumber()+"></input></td>"
                   +" <td><input type=text name=purchaseOrderNumber value="+order.getPurchaseOrderNumber()+"></input></td>"
                   +" <td><input type=text name=accountNumber value="+order.getAccountNumber()+"></input></td>"
                   +" <td><input type=text name =customerID value="+order.getCustomerId()+"></input></td>"
                   +" <td><input type=text name=salesPersonID value="+order.getSalesPersonId()+"></input></td>"
                   +"  <td><input type=text name=territoryID value="+order.getTerritoryId()+"></input></td>"
                   +"  <td><input type=text name=billToAddressID value="+order.getBillToaddressId()+"></input></td>"
                   +"  <td><input type=text name=shipToAddressID value="+order.getShipToaddressId()+"></input></td>"
                   +"  <td><input type=text name=shipMethodID value="+order.getShipMethodId()+"></input></td>"
                   +"  <td><input type=text name=creditCardID value="+order.getCreditCardId()+"></input></td>"
                   +"  <td><input type=text name=currencyRateID value="+order.getCurrencyRateID()+"></input></td>"
                   +"  <td><input type=text name=subTotal value="+order.getSubTotal()+"></input></td>"
                   +"  <td><input type=text name=taxAmt value="+order.getTaxAmnt()+"></input></td>"
                   +"<td><input type=text name=freight value="+order.getFreight()+"></input></td>"
                   +"<td><input type=text name=totalDue value="+order.getTotalDue()+"></input></td>"
                   +" <td><input type=text name=comment value="+order.getComment()+"></input></td>"
                   +"<td><input type=text name=modifiedDate value="+order.getModifiedDate()+"></input></td>"
                   +"  <td><input type=text name=creditCardApprovalCode value="+order.getCreditCardApprovalCode()+"></input></td>"
                   +" </tr>");
                      
                      
                        
            }
              getJspContext().setAttribute("OrderList", orderList, PageContext.SESSION_SCOPE);
        //   session.setAttribute("OrderList", orderList);
            out.print("<tr>"
//                    + " <td><input type=submit value=INSERT_INTO_DATABASE  name=csvSubmit/></td>"
                    + " </tr>"
                    + "  </table>"
                    
                    + "  </form>");

        }
   
    public void setCSVFileName(String CSVFileName) {
        this.CSVFileName = CSVFileName;
    }

}
