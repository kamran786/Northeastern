/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.DAO;

import com.neu.edu.pojo.SalesOrder;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Bhavik
 */
public class CsvDBDAO {

    public int addSales(ArrayList<SalesOrder> salesList) {

        java.sql.Connection connection = null;
        PreparedStatement stmt = null;
        int resultset =0;
        String sqlQuery = "INSERT INTO salesorder (SalesOrderID,RevisionNumber,OrderDate,DueDate,ShipDate,Status,OnlineOrderFlag,SalesOrderNumber,PurchaseOrderNumber,AccountNumber,CustomerID,SalesPersonID,TerritoryID,BillToAddressID,ShipToAddressID,ShipMethodID,CreditCardID,CreditCardApprovalCode,CurrencyRateID,SubTotal,TaxAmt,Freight,TotalDue,Comment,ModifiedDate) "
                + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/SalesOrderDB", "root", "Kemp@123");

            stmt = connection.prepareStatement(sqlQuery);

        } catch (ClassNotFoundException ex) {
            System.out.println("ClassNotFoundException" + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("SQLException" + ex.getMessage());
        }

        try {
            for (SalesOrder sales : salesList) {
                stmt.setString(1, sales.getSalesOrder());
                stmt.setString(2, sales.getRevisionNumber());
                stmt.setString(3, sales.getOrderDate());
                stmt.setString(4, sales.getDueDate());
                stmt.setString(5, sales.getShipDate());
                stmt.setInt(6, sales.getStatus());
                stmt.setInt(7, sales.getOnlineOrderFlag());
                stmt.setString(8, sales.getSalesOrderNumber());
                stmt.setString(9, sales.getPurchaseOrderNumber());
                stmt.setString(10, sales.getAccountNumber());
                stmt.setInt(11, sales.getCustomerId());
                stmt.setString(12, sales.getSalesPersonId());
                stmt.setString(13, sales.getTerritoryId());
                stmt.setString(14, sales.getBillToaddressId());
                stmt.setString(15, sales.getShipToaddressId());
                stmt.setString(16, sales.getShipMethodId());
                stmt.setString(17, sales.getCreditCardId());
                stmt.setString(18, sales.getCreditCardApprovalCode());
                stmt.setString(19, sales.getCurrencyRateID());
                stmt.setFloat(20, sales.getSubTotal());
                stmt.setFloat(21, (sales.getTaxAmnt()));
                stmt.setFloat(22, sales.getFreight());
                stmt.setFloat(23, sales.getTotalDue());
                stmt.setString(24, sales.getComment());
                stmt.setString(25, sales.getModifiedDate());
                stmt.addBatch();

            }

            int[] result = stmt.executeBatch();
            for(int i = 0; i< result.length;i++)
            {
                resultset++;
            }

        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                System.out.println("SQLException" + ex.getMessage());
            }
        }

        return resultset;
    }
}
