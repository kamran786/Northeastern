/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.me.pojo;



/**
 *
 * @author bshah
 */
public class SalesOrder {
 private String salesOrder;    
 private String revisionNumber;
 private String orderDate;
 private String dueDate;
 private String shipDate;
 private int status;
 private int onlineOrderFlag;
 private String salesOrderNumber;
 private String purchaseOrderNumber;
 private String accountNumber;
 private int customerId;
 private String salesPersonId;
 private String territoryId;
 private String billToaddressId;
 private String shipToaddressId;
 private String shipMethodId;
 private String creditCardId;
 private String creditCardApprovalCode;
 private String currencyRateID;
 private float subTotal;
 private float taxAmnt;
 private float freight;
 private float totalDue;
 private String comment;
 private String modifiedDate;

    public String getSalesOrder() {
        return salesOrder;
    }

    public String getRevisionNumber() {
        return revisionNumber;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public String getDueDate() {
        return dueDate;
    }

    public String getShipDate() {
        return shipDate;
    }

    public int getStatus() {
        return status;
    }

    public int getOnlineOrderFlag() {
        return onlineOrderFlag;
    }

    public String getSalesOrderNumber() {
        return salesOrderNumber;
    }

    public String getPurchaseOrderNumber() {
        return purchaseOrderNumber;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getSalesPersonId() {
        return salesPersonId;
    }

    public String getTerritoryId() {
        return territoryId;
    }

    public String getBillToaddressId() {
        return billToaddressId;
    }

    public String getShipToaddressId() {
        return shipToaddressId;
    }

    public String getShipMethodId() {
        return shipMethodId;
    }

    public String getCreditCardId() {
        return creditCardId;
    }

    public String getCreditCardApprovalCode() {
        return creditCardApprovalCode;
    }

    public String getCurrencyRateID() {
        return currencyRateID;
    }

    public float getSubTotal() {
        return subTotal;
    }

    public float getTaxAmnt() {
        return taxAmnt;
    }

    public float getFreight() {
        return freight;
    }

    public float getTotalDue() {
        return totalDue;
    }

    public String getComment() {
        return comment;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setSalesOrder(String salesOrder) {
        this.salesOrder = salesOrder;
    }

    public void setRevisionNumber(String revisionNumber) {
        this.revisionNumber = revisionNumber;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public void setShipDate(String shipDate) {
        this.shipDate = shipDate;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public void setOnlineOrderFlag(int onlineOrderFlag) {
        this.onlineOrderFlag = onlineOrderFlag;
    }

    public void setSalesOrderNumber(String salesOrderNumber) {
        this.salesOrderNumber = salesOrderNumber;
    }

    public void setPurchaseOrderNumber(String purchaseOrderNumber) {
        this.purchaseOrderNumber = purchaseOrderNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public void setSalesPersonId(String salesPersonId) {
        this.salesPersonId = salesPersonId;
    }

    public void setTerritoryId(String territoryId) {
        this.territoryId = territoryId;
    }

    public void setBillToaddressId(String billToaddressId) {
        this.billToaddressId = billToaddressId;
    }

    public void setShipToaddressId(String shipToaddressId) {
        this.shipToaddressId = shipToaddressId;
    }

    public void setShipMethodId(String shipMethodId) {
        this.shipMethodId = shipMethodId;
    }

    public void setCreditCardId(String creditCardId) {
        this.creditCardId = creditCardId;
    }

    public void setCreditCardApprovalCode(String creditCardApprovalCode) {
        this.creditCardApprovalCode = creditCardApprovalCode;
    }

    public void setCurrencyRateID(String currencyRateID) {
        this.currencyRateID = currencyRateID;
    }

    public void setSubTotal(float subTotal) {
        this.subTotal = subTotal;
    }

    public void setTaxAmnt(float taxAmnt) {
        this.taxAmnt = taxAmnt;
    }

    public void setFreight(float freight) {
        this.freight = freight;
    }

    public void setTotalDue(float totalDue) {
        this.totalDue = totalDue;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
    

 
         
}
