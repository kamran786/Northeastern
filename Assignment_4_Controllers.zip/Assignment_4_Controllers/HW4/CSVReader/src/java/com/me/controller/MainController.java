/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.me.controller;

import com.me.DAO.CsvDAO;
import com.me.DAO.CsvDBDAO;
import com.me.pojo.SalesOrder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author bshah
 */
public class MainController extends AbstractController {

    @Override
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //   throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        HttpSession session = request.getSession();
       
       //
        String fileName = request.getParameter("csvFile");
        String db = request.getParameter("database");
        ModelAndView mav = null;
        if(fileName ==null && db == null){
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("msgtype", "search");
            mav = new ModelAndView("index", "map", map);
        }
        else if (fileName !=null && !fileName.isEmpty() && db == null ) {
            CsvDAO cdao = (CsvDAO) this.getApplicationContext().getBean("csvdao");
            ArrayList<SalesOrder> sOrder = cdao.getFile(fileName);
            if (sOrder.size() > 0) {
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("OrderList", sOrder);
                map.put("msgtype", "display");
                session.setAttribute("OrderList", sOrder);
                mav = new ModelAndView("index", "map", map);
            } else {
                System.out.println("hi");
            }
        }
        else if(db.equals("db")){
            ArrayList<SalesOrder> sOrder = (ArrayList<SalesOrder>) session.getAttribute("OrderList");
            CsvDBDAO cdao = (CsvDBDAO) this.getApplicationContext().getBean("csvdbdao");
            int result = cdao.addSales(sOrder);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("resultset",result);
            map.put("msgtype", "last");
            mav = new ModelAndView("index","map",map);
        }
        
        return mav;
    }
}
