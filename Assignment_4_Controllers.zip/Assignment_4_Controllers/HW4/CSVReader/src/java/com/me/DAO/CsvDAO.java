package com.me.DAO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author bshah
 */
import com.me.pojo.SalesOrder;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.relique.jdbc.csv.CsvDriver;

public class CsvDAO
{
    
public ArrayList<SalesOrder> getFile(String fileName){
       ArrayList<SalesOrder> orderList = new ArrayList<SalesOrder>();  
     try {
     Class.forName("org.relique.jdbc.csv.CsvDriver");
      } catch (ClassNotFoundException ex) {
          Logger.getLogger(CsvDAO.class.getName()).log(Level.SEVERE, null, ex);
      }
    
    // Create a connection. The first command line parameter is
    // the directory containing the .csv files.
    // A single connection is thread-safe for use by several threads.  c:/mydir/csvfiles

    Connection conn;//C:\
      try {//localhost:3306/booksdb.sql.SQLException) java.sql.SQLException: Directory not found: C:\SalesOrder\
          conn = DriverManager.getConnection("jdbc:relique:csv:C:");
          Statement stmt = conn.createStatement();

    // Select the ID and NAME columns from sample.csv
    ResultSet results = stmt.executeQuery("SELECT SalesOrderID,RevisionNumber,OrderDate,DueDate,ShipDate,Status,OnlineOrderFlag,SalesOrderNumber,PurchaseOrderNumber,AccountNumber,CustomerID,SalesPersonID,TerritoryID,BillToAddressID,ShipToAddressID,ShipMethodID,CreditCardID,CreditCardApprovalCode,CurrencyRateID,SubTotal,TaxAmt,Freight,TotalDue,Comment,ModifiedDate FROM "+fileName);
   
    while (results.next()) {
                SalesOrder sOrder = new SalesOrder();
                sOrder.setSalesOrder(results.getString("SalesOrderID"));
                sOrder.setRevisionNumber(results.getString("RevisionNumber"));
                sOrder.setOrderDate(results.getString("OrderDate"));
                sOrder.setDueDate(results.getString("DueDate"));
                sOrder.setShipDate(results.getString("ShipDate"));
                sOrder.setStatus(Integer.parseInt(results.getString("Status")));
                sOrder.setOnlineOrderFlag(Integer.parseInt(results.getString("OnlineOrderFlag")));
                sOrder.setSalesOrderNumber(results.getString("SalesOrderNumber"));
                sOrder.setPurchaseOrderNumber(results.getString("PurchaseOrderNumber"));
                sOrder.setAccountNumber(results.getString("AccountNumber"));
                sOrder.setCustomerId(Integer.parseInt(results.getString("CustomerID")));
                sOrder.setSalesPersonId(results.getString("SalesPersonID"));
                sOrder.setTerritoryId(results.getString("TerritoryID"));
                sOrder.setBillToaddressId(results.getString("BillToAddressID"));
                sOrder.setShipToaddressId(results.getString("ShipToAddressID"));
                sOrder.setShipMethodId(results.getString("ShipMethodID"));
                sOrder.setCreditCardId(results.getString("CreditCardID"));
                sOrder.setCreditCardApprovalCode(results.getString("CreditCardApprovalCode"));
                sOrder.setCurrencyRateID(results.getString("CurrencyRateID"));
                sOrder.setSubTotal(Float.parseFloat(results.getString("SubTotal")));
                sOrder.setTaxAmnt(Float.parseFloat(results.getString("TaxAmt")));
                sOrder.setFreight(Float.parseFloat(results.getString("Freight")));
                sOrder.setTotalDue(Float.parseFloat(results.getString("TotalDue")));
                sOrder.setComment(results.getString("Comment"));
                sOrder.setModifiedDate(results.getString("ModifiedDate"));
                orderList.add(sOrder);
            }                                                                                                                                                                                                                  

    // Dump out the results to a CSV file with the same format
    // using CsvJdbc helper function
    boolean append = true;
    //CsvDriver.writeToCsv(results, System.out, append);

    // Clean up
    conn.close();
   
    
      } catch (SQLException ex) {
          Logger.getLogger(CsvDAO.class.getName()).log(Level.SEVERE, null, ex);
      }

    // Create a Statement object to execute the query with.
    // A Statement is not thread-safe.
    return orderList;
   }

}