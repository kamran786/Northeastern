/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.me.DAO;

import com.me.pojo.Books;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Bhavik
 */
public class BooksDAO {

    public boolean addBooks(ArrayList<Books> booksList) {

        java.sql.Connection connection = null;
        PreparedStatement stmt = null;
        String sqlQuery = "INSERT INTO books (isbn, title, authors, price) "
                + "VALUES (?,?,?,?)";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/booksdb", "root", "root");

            stmt = connection.prepareStatement(sqlQuery);

        } catch (ClassNotFoundException ex) {
            System.out.println("ClassNotFoundException" + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("SQLException" + ex.getMessage());
        }

        try {
            for (Books books : booksList) {
                stmt.setString(1, books.getIsbn());
                stmt.setString(2, books.getTitle());
                stmt.setString(3, books.getAuthor());
                stmt.setFloat(4, Float.parseFloat(books.getPrice()));
                stmt.executeUpdate();

            }

            

        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                System.out.println("SQLException" + ex.getMessage());
            }
        }

        return false;
    }
}
