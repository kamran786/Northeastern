/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.me.controller;

import com.me.DAO.BooksDAO;
import com.me.pojo.Books;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author bshah
 */
public class BooksController extends AbstractController{

    public BooksController() {
    }


    @Override
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession();
        String booksNumber = request.getParameter("booksNumber");
        
        if(request.getRequestURI().endsWith("books.htm")){
        session.setAttribute("BookNumber",booksNumber);
        return new ModelAndView("books","BookNumber", booksNumber);
        }
        else if(request.getRequestURI().endsWith("success.htm")){
            BooksDAO mdao = (BooksDAO) this.getApplicationContext().getBean("booksdao");
            int booksNo = Integer.parseInt(request.getParameter("bookmark"));
            ArrayList<Books> booksList = new ArrayList<Books>();
            for(int i = 1; i<=booksNo; i++){
                Books books = new Books();
                books.setIsbn(request.getParameter("isbn"+i+""));
                books.setAuthor(request.getParameter("author"+i));
                books.setTitle(request.getParameter("title"+i));
                books.setPrice(request.getParameter("price"+i));
                booksList.add(books);
            }
                mdao.addBooks(booksList);
                return new ModelAndView("success","booksNo",booksNo);
        }   
        return null;
    }
       
}
