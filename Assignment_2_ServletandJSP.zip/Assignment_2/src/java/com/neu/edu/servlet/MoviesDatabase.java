/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MoviesDatabase extends HttpServlet {

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String optionSelected = request.getParameter("option");

        if (optionSelected.equals("browse")) {
            RequestDispatcher rd = request.getRequestDispatcher("search.jsp");
            rd.forward(request, response);
        } else if (optionSelected.equals("add")) {
            RequestDispatcher rd = request.getRequestDispatcher("add.jsp");
            rd.forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver is missing");
            e.printStackTrace();
            return;
        }

        Connection connection = null;

        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviesDB", "root", "Kemp@123");

        } catch (SQLException e) {
            System.out.println("Unable to connect.");
            e.printStackTrace();
            return;
        }

        if (connection
                != null) {
            String movie = req.getParameter("movie");
            if (movie.equals("add")) {
                String movie_title = req.getParameter("movietitle");
                String movie_actor = req.getParameter("leadactor");
                String movie_actress = req.getParameter("leadactress");
                String movie_genre = req.getParameter("genre");
                String movie_year = req.getParameter("year");

                try {
                    Statement st = connection.createStatement();
                    st.executeUpdate("INSERT INTO MOVIES "
                            + "VALUES ('" + movie_title + "', '" + movie_actor + "','" + movie_actress + "','" + movie_genre + "','" + movie_year + "')");

                    out.println("<html>");
                    out.println("<head>");
                    out.println("</head>");
                    out.println("<body>");
                    out.println("<h2>1 Movie Added Successfully!!!</h2>");
                    out.println("<a href=\"home.jsp\">Main page</a> <br></br>");
                    out.println("</body>");
                    out.println("</html>");
                } catch (SQLException ex) {
                    System.err.println(ex.getMessage());
                }

            } else if (movie.equals("search")) {
                String option = req.getParameter("option");
                String keyword = req.getParameter("keyword");

                String query = "SELECT title, actor, actress, genre, year FROM MOVIES WHERE " + option + "= " + "'" + keyword + "'";
                try {
                    Statement st = connection.createStatement();
                    ResultSet rs = st.executeQuery(query);
                    out.println("<html>");
                    out.println("<head>");
                    out.println("</head>");
                    out.println("<body>");
                 //   out.println("<h2>You searched for: " + keyword + "</h2>");
                    out.println("<p>Search results for:" + keyword + "</p>");
                    while (rs.next()) {
                        out.println("<p>Title: " + rs.getString("title") + "</p>");
                        out.println("<p>Lead Actor: " + rs.getString("actor") + "</p>");
                        out.println("<p>Lead Actress: " + rs.getString("actress") + "</p>");
                        out.println("<p>Genre: " + rs.getString("genre") + "</p>");
                        out.println("<p>Year: " + String.valueOf(rs.getInt("year")) + "</p>");
                        out.println("<br></br> <br></br>");
                    }
                } catch (SQLException ex) {
                    System.err.println(ex.getMessage());
                }
            }

        } else {
            System.out.println("Failed to connect.");
        }
    }
}
