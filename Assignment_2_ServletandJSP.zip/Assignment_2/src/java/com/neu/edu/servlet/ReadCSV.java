package com.neu.edu.servlet;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ReadCSV extends HttpServlet
{
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
      PrintWriter out = response.getWriter();
    try
    {
      // load the driver into memory
      Class.forName("org.relique.jdbc.csv.CsvDriver");

      // create a connection. The first command line parameter is assumed to
      //  be the directory in which the .csv files are held
      Connection conn = DriverManager.getConnection("jdbc:relique:csv:" );

      // create a Statement object to execute the query with
      Statement stmt = conn.createStatement();

      // Select the ID and NAME columns from sample.csv
      
      ResultSet results = stmt.executeQuery("SELECT * FROM C:\\Users\\kahma\\Downloads\\SalesOrder");
      ResultSetMetaData meta = results.getMetaData();

      // dump out the results
      
      out.println("<html>");
			out.println("<head>");
			out.println("</head>");
			out.println("<body>");
                        out.println("<table>");
                        out.println("<tr>");
                        out.println("<th>SalesOrderID</th>");
                        out.println("<th>RevisionNumber</th>");
                        out.println("<th>OrderDate</th>");
                        out.println("<th>DueDate</th>");
                        out.println("<th>ShipDate</th>");
                        out.println("<th>Status</th>");
                        out.println("<th>OnlineOrderFlag</th>");
                        out.println("<th>SalesOrderNumber</th>");
                        out.println("<th>PurchaseOrderNumber</th>");
                        out.println("<th>AccountNumber</th>");
                        out.println("<th>CustomerID</th>");
                        out.println("<th>SalesPersonID</th>");
                        out.println("<th>TerritoryID</th>");
                        out.println("<th>BillToAddressID</th>");
                        out.println("<th>ShipToAddressID</th>");
                        out.println("<th>ShipMethodID</th>");
                        out.println("<th>CreditCardID</th>");
                        out.println("<th>CreditCardApprovalCode</th>");
                        out.println("<th>CurrencyRateID</th>");
                        out.println("<th>SubTotal</th>");
                        out.println("<th>TaxAmt</th>");
                        out.println("<th>Freight</th>");
                        out.println("<th>TotalDue</th>");
                        out.println("<th>Comment</th>");
                        out.println("<th>ModifiedDate</th>");
                        out.println("</tr>");
                        
                        
			while (results.next())
      {
          out.println("</tr>");
       for (int i = 0; i < meta.getColumnCount(); i++) {
                out.println("<td>" + results.getString(i + 1) + "</td>");
               
            }
       out.println("</tr>");
      }
                        
			out.println("<div id='ch'></div>");
			out.println("</form>");
			out.println("</body>");
			out.println("</html>");


      // clean up
      results.close();
      stmt.close();
    }
    catch(Exception e)
    {
      out.println("Oops-> " + e);
    }
  }
}