/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.servlet;

import com.neu.edu.pojo.BookDetails;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class BooksDatabase extends HttpServlet {
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String cnt = request.getParameter("cnt");
                
                
		if (cnt == null)
		{
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Books Details</title>");			
			out.println("<script type='text/javascript'>");
			out.println("function pageGenerate() {");
			out.println("var a = parseInt(document.getElementById('cnt').value);");
			out.println("var url = 'BooksDatabase?cnt=' +a ;");
			out.println("window.location= url;");		
			out.println("}");
			out.println("</script>");			
			out.println("</head>");
			out.println("<body>");
			out.println("How many Books do you want to add?");
			out.println("<input type='text' name='cnt' id='cnt' /><br />");			
			out.println("<input type='button' value ='Submit Query' onclick='pageGenerate()'/>");
			out.println("<div id='ch'></div>");
			out.println("</body>");
			out.println("</html>");
		}
		else
		{
			int c = Integer.parseInt(cnt);
			HttpSession session = request.getSession();
			session.setAttribute("cnt",c);
			out.println("<html>");
			out.println("<head>");
			out.println("</head>");
			out.println("<body>");
                        out.println("<table>");
                        out.println("<tr>");
                        out.println("<th>Isdn</th>");
                        out.println("<th>Book Title</th>");
                        out.println("<th>Author</th>");
                        out.println("<th>Price</th>");
                        out.println("</tr>");
			out.println("<form action = 'BooksDatabase' method = 'post'>");
			for(int i=0;i<c;i++)
			{
				//String name = "c"+(i+1);
                                
                        out.println("<tr>");
                        out.println("<td><input type='text' name='isdn' id='cnt' /><br /></td>");
                        out.println("<td><input type='text' name='booktitle' id='cnt' /><br /></td>");
                        out.println("<td><input type='text' name='author' id='cnt' /><br /></td>");
                        out.println("<td><input type='text' name='price' id='cnt' /><br /></td>");
                        out.println("</tr>");
			}
			out.println("<input type =  'submit' value = 'Submit' name = 'Submit'/><br /></p>");
			out.println("<div id='ch'></div>");
			out.println("</form>");
			out.println("</body>");
			out.println("</html>");
			
		}
       String isdn = request.getParameter("isdn");
       String booktitle = request.getParameter("booktitle");
       String author = request.getParameter("author");
       String price = (String) request.getParameter("price");
       BookDetails bd = new BookDetails();
       bd.setIsbn(isdn);
       bd.setBookTitle(booktitle);
       bd.setAuthor(author);
//       try
//       {
//    //   bd.setPrice(Float.valueOf(price));
//       }
//       catch(Exception e)
//               {
//                   addBooks(bd);
//               }
       //Add message to table
     //  addBooks(bd);	
	}
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();	
		int c = (Integer) session.getAttribute("cnt");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Servletp6</title>");
		out.println("</head>");
		out.println("<body>");

		out.println(c + "books are submitted successfully");

		out.println("</body>");
		out.println("</html>");
                
       String isdn = request.getParameter("isdn");
       String booktitle = request.getParameter("booktitle");
       String author = request.getParameter("author");
       String price = (String) request.getParameter("price");
       BookDetails bd = new BookDetails();
       bd.setIsbn(isdn);
       bd.setBookTitle(booktitle);
       bd.setAuthor(author);
//       try
//       {
//    //   bd.setPrice(Float.valueOf(price));
//       }
//       catch(Exception e)
//               {
//                   addBooks(bd);
//               }

        addBooks(bd);
		
    }
    
    public boolean addBooks(BookDetails bookDetails) {
            java.sql.Connection connection = null;
            Statement stmt = null;
            try {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/booksdb", "root", "Kemp@123");
                //DriverManager.getConnection("jdbc:mysql://newton.neu.edu:3306/moviedb", "student", "p@ssw0rd");
                stmt = connection.createStatement();
            } catch (ClassNotFoundException ex) {
                System.out.println("ClassNotFoundException" + ex.getMessage());
            } catch (SQLException ex) {
                System.out.println("SQLException" + ex.getMessage());
            }

            String sqlQuery = "INSERT INTO booksdb.books (ISBN, author, title, price) "
                    + "VALUES ('" + bookDetails.getIsbn()+ "', '" + bookDetails.getAuthor() + "','" + bookDetails.getBookTitle() + "'," +  bookDetails.getPrice() + ")";
            try {
                stmt.executeUpdate(sqlQuery);
                System.out.println(sqlQuery);

            } catch (SQLException ex) {
                System.out.println(ex);
            } finally {
                try {
                    if (stmt != null) {
                        stmt.close();
                    }
                    if (connection != null) {
                        connection.close();
                    }
                } catch (SQLException ex) {
                    System.out.println("SQLException" + ex.getMessage());
                }
            }
            return false;
        }
    
    
    
}