/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.servlet;

import com.neu.edu.pojo.Orders;
import com.neu.edu.pojo.Returns;
import com.neu.edu.pojo.People;
import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author kahma
 */
public class Readxls extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String requestXLS = req.getParameter("requestXLS");
        String filepath = "C:\\Users\\kahma\\Downloads\\" + requestXLS + ".xls";
        
        List<Orders> listBooks = new ArrayList<>();
        List<Returns> listReturns = new ArrayList<>();
        List<People> listPeople = new ArrayList<>();
        FileInputStream inputStream = new FileInputStream(new File(filepath));

        Workbook workbook = WorkbookFactory.create(inputStream);
        Sheet sheet = workbook.getSheetAt(0);
        Iterator<Row> iterator = sheet.iterator();
        DataFormatter dataFormatter = new DataFormatter();

        while (iterator.hasNext()) {
            Row nextRow = iterator.next();
            Iterator<Cell> cellIterator = nextRow.cellIterator();
            Orders aBook = new Orders();

            while (cellIterator.hasNext()) {
                Cell nextCell = cellIterator.next();
                int columnIndex = nextCell.getColumnIndex();
                String cellValue = dataFormatter.formatCellValue(nextCell);
                switch (columnIndex) {

                    case 0:
                        aBook.setXls_RowID(cellValue);
                        break;

                    case 1:
                        aBook.setXls_OrderID(cellValue);
                        break;

                    case 2:
                        aBook.setXlsOrderDate(cellValue);
                        break;

                    case 3:
                        aBook.setXls_ShipDate(cellValue);
                        break;
                    case 4:
                        aBook.setXls_ShipMode(cellValue);
                        break;
                    case 5:
                        aBook.setXls_CustomerID(cellValue);
                        break;
                    case 6:
                        aBook.setXls_CustomerName(cellValue);
                        break;
                    case 7:
                        aBook.setXls_Segment(cellValue);
                        break;
                    case 8:
                        aBook.setXls_Country(cellValue);
                        break;
                    case 9:
                        aBook.setXls_City(cellValue);
                        break;
                    case 10:
                        aBook.setXls_State(cellValue);
                        break;
                    case 11:
                        aBook.setXls_PostalCode(cellValue);
                        break;
                    case 12:
                        aBook.setXls_Region(cellValue);
                        break;
                    case 13:
                        aBook.setXls_ProductID(cellValue);
                        break;
                    case 14:
                        aBook.setXls_Category(cellValue);
                        break;
                    case 15:
                        aBook.setXls_SubCategory(cellValue);
                        break;
                    case 16:
                        aBook.setXls_ProductName(cellValue);
                        break;
                    case 17:
                        aBook.setXls_Sales(cellValue);
                        break;
                    case 18:
                        aBook.setXls_Quantity(cellValue);
                        break;
                    case 19:
                        aBook.setXls_Discount(cellValue);
                        break;
                    case 20:
                        aBook.setXls_Profit(cellValue);
                        break;
                }

            }
            listBooks.add(aBook);
        }

        sheet = workbook.getSheetAt(1);
        iterator = sheet.iterator();
        dataFormatter = new DataFormatter();

        while (iterator.hasNext()) {
            Row nextRow = iterator.next();
            Iterator<Cell> cellIterator = nextRow.cellIterator();
            Returns aReturns = new Returns();

            while (cellIterator.hasNext()) {
                Cell nextCell = cellIterator.next();
                int columnIndex = nextCell.getColumnIndex();
                String cellValue = dataFormatter.formatCellValue(nextCell);
                switch (columnIndex) {

                    case 0:
                        aReturns.setXls_Returned(cellValue);
                        break;

                    case 1:
                        aReturns.setXls_OrderID(cellValue);
                        break;
                }

            }
            listReturns.add(aReturns);
        }

        sheet = workbook.getSheetAt(1);
        iterator = sheet.iterator();
        dataFormatter = new DataFormatter();

        while (iterator.hasNext()) {
            Row nextRow = iterator.next();
            Iterator<Cell> cellIterator = nextRow.cellIterator();
            People people = new People();

            while (cellIterator.hasNext()) {
                Cell nextCell = cellIterator.next();
                int columnIndex = nextCell.getColumnIndex();
                String cellValue = dataFormatter.formatCellValue(nextCell);
                switch (columnIndex) {

                    case 0:
                        people.setXls_Person(cellValue);
                        break;

                    case 1:
                        people.setXls_Region(cellValue);
                        break;

                }

            }
            listPeople.add(people);
        }

        workbook.close();
        inputStream.close();

        req.setAttribute("orders", listBooks);
        req.setAttribute("returns", listReturns);
        req.setAttribute("people", listPeople);
        RequestDispatcher requestDispatcher = req.getRequestDispatcher("Displayxls.jsp");
        requestDispatcher.forward(req, resp);
    }

}
