/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

import java.io.PrintWriter;

public class AddtoCart extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
		
		out.println("<html>");
                out.println("<head>");

                out.println("</head>");
                out.println("<body>");
                out.println("<h2>The following Item has been added to your shopping cart successfully</h2>");
				
		Enumeration paramNames = request.getParameterNames();
        while(paramNames.hasMoreElements()) {
      String paramName = (String)paramNames.nextElement();
      String[] paramValues = request.getParameterValues(paramName);
		  session.setAttribute(paramName,paramValues);
		 doPost(request,response);
	}
	}
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(false);
		Enumeration<String> attrs =  session.getAttributeNames();
        while(attrs.hasMoreElements()) {
			String attributes = attrs.nextElement();
			String[] values = (String[])request.getSession().getAttribute(attributes);
			for(String v : values)
			{
				out.println("<p>"+v+"</p>");
		}
		}
		

		out.println("<a href=\"index.html\"> Back to Home</a>");
                out.println("</body>");
                out.println("</html>");
		
	}
}