/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.pojo;

/**
 *
 * @author kahma 
 */
public class Orders {
    private String xls_RowID;
    private String xls_OrderID;
    private String xlsOrderDate;
    private String xls_ShipDate;
    private String xls_ShipMode;
    private String xls_CustomerID;
    private String xls_CustomerName;
    private String xls_Segment;
    private String xls_Country;
    private String xls_City;
    private String xls_State;
    private String xls_PostalCode;
    private String xls_Region;
    private String xls_ProductID;
    private String xls_Category;
    private String xls_SubCategory;
    private String xls_ProductName;
    private String xls_Sales;
    private String xls_Quantity;
    private String xls_Discount;
    private String xls_Profit;

    public String getXls_RowID() {
        return xls_RowID;
    }

    public void setXls_RowID(String xls_RowID) {
        this.xls_RowID = xls_RowID;
    }

    public String getXls_OrderID() {
        return xls_OrderID;
    }

    public void setXls_OrderID(String xls_OrderID) {
        this.xls_OrderID = xls_OrderID;
    }

    public String getXlsOrderDate() {
        return xlsOrderDate;
    }

    public void setXlsOrderDate(String xlsOrderDate) {
        this.xlsOrderDate = xlsOrderDate;
    }

    public String getXls_ShipDate() {
        return xls_ShipDate;
    }

    public void setXls_ShipDate(String xls_ShipDate) {
        this.xls_ShipDate = xls_ShipDate;
    }

    public String getXls_ShipMode() {
        return xls_ShipMode;
    }

    public void setXls_ShipMode(String xls_ShipMode) {
        this.xls_ShipMode = xls_ShipMode;
    }

    public String getXls_CustomerID() {
        return xls_CustomerID;
    }

    public void setXls_CustomerID(String xls_CustomerID) {
        this.xls_CustomerID = xls_CustomerID;
    }

    public String getXls_CustomerName() {
        return xls_CustomerName;
    }

    public void setXls_CustomerName(String xls_CustomerName) {
        this.xls_CustomerName = xls_CustomerName;
    }

    public String getXls_Segment() {
        return xls_Segment;
    }

    public void setXls_Segment(String xls_Segment) {
        this.xls_Segment = xls_Segment;
    }

    public String getXls_Country() {
        return xls_Country;
    }

    public void setXls_Country(String xls_Country) {
        this.xls_Country = xls_Country;
    }

    public String getXls_City() {
        return xls_City;
    }

    public void setXls_City(String xls_City) {
        this.xls_City = xls_City;
    }

    public String getXls_State() {
        return xls_State;
    }

    public void setXls_State(String xls_State) {
        this.xls_State = xls_State;
    }

    public String getXls_PostalCode() {
        return xls_PostalCode;
    }

    public void setXls_PostalCode(String xls_PostalCode) {
        this.xls_PostalCode = xls_PostalCode;
    }

    public String getXls_Region() {
        return xls_Region;
    }

    public void setXls_Region(String xls_Region) {
        this.xls_Region = xls_Region;
    }

    public String getXls_ProductID() {
        return xls_ProductID;
    }

    public void setXls_ProductID(String xls_ProductID) {
        this.xls_ProductID = xls_ProductID;
    }

    public String getXls_Category() {
        return xls_Category;
    }

    public void setXls_Category(String xls_Category) {
        this.xls_Category = xls_Category;
    }

    public String getXls_SubCategory() {
        return xls_SubCategory;
    }

    public void setXls_SubCategory(String xls_SubCategory) {
        this.xls_SubCategory = xls_SubCategory;
    }

    public String getXls_ProductName() {
        return xls_ProductName;
    }

    public void setXls_ProductName(String xls_ProductName) {
        this.xls_ProductName = xls_ProductName;
    }

    public String getXls_Sales() {
        return xls_Sales;
    }

    public void setXls_Sales(String xls_Sales) {
        this.xls_Sales = xls_Sales;
    }

    public String getXls_Quantity() {
        return xls_Quantity;
    }

    public void setXls_Quantity(String xls_Quantity) {
        this.xls_Quantity = xls_Quantity;
    }

    public String getXls_Discount() {
        return xls_Discount;
    }

    public void setXls_Discount(String xls_Discount) {
        this.xls_Discount = xls_Discount;
    }

    public String getXls_Profit() {
        return xls_Profit;
    }

    public void setXls_Profit(String xls_Profit) {
        this.xls_Profit = xls_Profit;
    }



}
