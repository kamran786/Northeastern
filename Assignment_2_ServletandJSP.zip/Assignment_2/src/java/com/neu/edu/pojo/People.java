/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.pojo;

/**
 *
 * @author kahma
 */
public class People {
    
    private String xls_Person;
    private String xls_Region;

    public String getXls_Person() {
        return xls_Person;
    }

    public void setXls_Person(String xls_Person) {
        this.xls_Person = xls_Person;
    }

    public String getXls_Region() {
        return xls_Region;
    }

    public void setXls_Region(String xls_Region) {
        this.xls_Region = xls_Region;
    }


}
