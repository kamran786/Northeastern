/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.pojo;

/**
 *
 * @author kahma
 */
public class Returns {
    
    private String xls_Returned;
    private String xls_OrderID;

    public String getXls_Returned() {
        return xls_Returned;
    }

    public void setXls_Returned(String xls_Returned) {
        this.xls_Returned = xls_Returned;
    }

    public String getXls_OrderID() {
        return xls_OrderID;
    }

    public void setXls_OrderID(String xls_OrderID) {
        this.xls_OrderID = xls_OrderID;
    }


}
